################################################
#                                              #
#                                              #
#        search.py - Search Engine             #
#             Version 1.0.0                    #
#                                              #
#        Created by: WolfStudios               #
#                                              #
################################################

import json
import re
from collections import Counter


class SearchEngine:
    def __init__(self, json_file):
        with open(json_file, "r", encoding="utf-8") as f:
            self.data = json.load(f)

        self.documents = self.data["sentences"]
        
        self.question_regex = re.compile(
            r"^(?:"
            r"(?:can|could|would)\s+(?:you\s+)?(?:tell|show|find|give)\s+(?:me\s+)?"
            r"|please\s+(?:show|find|tell)\s+(?:me\s+)?"
            r"|(?:what|who|where|when|why|how|which)"
            r")"
            r"(?:\s+(?:is|are|was|were|do|does|did|can|could|should|would|to|about|in|on))?"
            r"(?:\s+(?:the|a|an|my|your|our|some))?"
            r"\b",
            re.IGNORECASE,
        )
        
    def clean_query(self, query: str) -> str:
            cleaned = query.strip()

            while True:
                new_cleaned = self.question_regex.sub("", cleaned).strip()
                if new_cleaned == cleaned:
                    break
                cleaned = new_cleaned

            return cleaned if cleaned else query.strip()

    def tokenize(self, text):
        return re.findall(r"\b[a-zA-Z0-9]+\b", text.lower())

    def _extract_phrases(self, tokens, n=2):
        return [" ".join(tokens[i : i + n]) for i in range(len(tokens) - n + 1)]

    def score_document_first_pass(self, query, doc):
        score = 0
        query_words = self.tokenize(query)

        keywords = [k.lower() for k in doc.get("keywords", [])]
        text = doc.get("text", "").lower()
        topic = str(doc.get("topic_genre", "")).lower()

        for word in query_words:
            if word in keywords:
                score += 5
            if word in text:
                score += 2

        if topic not in ("none", "null", ""):
            for word in query_words:
                if word in topic:
                    score += 8

        dates = doc.get("dates_times", [])
        if dates:
            for date in dates:
                if str(date).lower() in query.lower():
                    score += 10

        if query.lower() in text and len(query.strip()) > 0:
            score += 20

        return score

    def calculate_doc_similarity(self, candidate_a, candidate_b):
        score = 0.0

        # 1. Keyword overlap (Jaccard similarity)
        kw_a = set(k.lower() for k in candidate_a["doc"].get("keywords", []))
        kw_b = set(k.lower() for k in candidate_b["doc"].get("keywords", []))
        if kw_a and kw_b:
            jaccard_kw = len(kw_a.intersection(kw_b)) / len(kw_a.union(kw_b))
            score += jaccard_kw * 10.0

        # 2. Topic overlap
        topic_a = candidate_a["doc"].get("topic_genre")
        topic_b = candidate_b["doc"].get("topic_genre")
        if (
            topic_a
            and topic_b
            and str(topic_a).lower() == str(topic_b).lower()
        ):
            score += 5.0

        # 3. Phrase overlap (using 2-gram overlap from text)
        phrases_a = set(self._extract_phrases(candidate_a["tokens"], n=2))
        phrases_b = set(self._extract_phrases(candidate_b["tokens"], n=2))
        if phrases_a and phrases_b:
            phrase_intersection = len(phrases_a.intersection(phrases_b))
            score += phrase_intersection * 2.0

        return score

    def search(self, query, top_k_candidates=50, limit=5):
        cleaned_query = self.clean_query(query)

        # 1. Tokenize Cleaned Query
        query_tokens = set(self.tokenize(cleaned_query))
        if not query_tokens:
            return []
        
        candidates = []
        for doc in self.documents:
            fp_score = self.score_document_first_pass(cleaned_query, doc)
            if fp_score > 0:
                candidates.append(
                    {
                        "doc": doc,
                        "first_pass_score": fp_score,
                        "tokens": self.tokenize(doc.get("text", "")),
                        "graph_votes": 0.0,
                        "expansion_score": 0.0,
                        "final_score": 0.0,
                    }
                )

        if not candidates:
            return []

        # 3. Filter to Top 50 Candidates
        candidates.sort(key=lambda x: x["first_pass_score"], reverse=True)
        top_candidates = candidates[:top_k_candidates]

        # 4. Consensus Analysis (Common keywords, topics, phrases across top candidates)
        consensus_keywords = Counter()
        consensus_topics = Counter()
        consensus_phrases = Counter()

        for cand in top_candidates:
            doc = cand["doc"]
            for kw in doc.get("keywords", []):
                consensus_keywords[kw.lower()] += 1

            topic = doc.get("topic_genre")
            if topic and str(topic).lower() not in ("none", "null"):
                consensus_topics[str(topic).lower()] += 1

            phrases = self._extract_phrases(cand["tokens"], n=2)
            for phrase in phrases:
                consensus_phrases[phrase] += 1

        # 5. Document Similarity & 6. Graph Voting
        num_candidates = len(top_candidates)
        for i in range(num_candidates):
            for j in range(i + 1, num_candidates):
                sim = self.calculate_doc_similarity(
                    top_candidates[i], top_candidates[j]
                )
                if sim > 0:
                    top_candidates[i]["graph_votes"] += sim
                    top_candidates[j]["graph_votes"] += sim

        # 7. Intent Expansion
        expanded_features = set()
        for kw, count in consensus_keywords.most_common(5):
            if kw not in query_tokens:
                expanded_features.add(kw)

        for phrase, count in consensus_phrases.most_common(5):
            if phrase not in query.lower():
                expanded_features.add(phrase)

        for cand in top_candidates:
            cand_text = cand["doc"].get("text", "").lower()
            cand_kws = [
                k.lower() for k in cand["doc"].get("keywords", [])
            ]

            for feature in expanded_features:
                if feature in cand_kws or feature in cand_text:
                    cand["expansion_score"] += 3.0

        # 8. Final Re-ranking
        for cand in top_candidates:
            cand["final_score"] = (
                cand["first_pass_score"]
                + (cand["graph_votes"] * 0.2)
                + cand["expansion_score"]
            )

        top_candidates.sort(key=lambda x: x["final_score"], reverse=True)

        # 9. Format Top Results
        results = []
        for cand in top_candidates[:limit]:
            results.append(
                {
                    "score": round(cand["final_score"], 2),
                    "id": cand["doc"]["id"],
                    "text": cand["doc"]["text"],
                    "topic": cand["doc"].get("topic_genre"),
                }
            )

        return results


# -------------------------
# Example usage
# -------------------------
if __name__ == "__main__":
    engine = SearchEngine("data.json")

    while True:
        query = input("\nSearch: ")

        if not query.strip():
            continue

        results = engine.search(query)

        if not results:
            print("No results found")
            continue

        print("\nResults:")
        for r in results:
            print(f"\n[{r['score']}] (Topic: {r['topic']}) {r['text']}")