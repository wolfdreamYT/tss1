################################################
#                                              #
#                                              #
#        split.py - Sentence Splitter          #
#             Version 1.0.0                    #
#                                              #
#        Created by: WolfStudios               #
#                                              #
################################################

from collections import Counter
import json
import math
import os
import re
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize

from data.topics import TOPICS

nltk.download("punkt")
nltk.download("punkt_tab")
nltk.download("stopwords")

STOP_WORDS = set(stopwords.words("english"))

# -----------------------------
# Sentence Tokenizer Setup
# -----------------------------
sentence_tokenizer = nltk.data.load("tokenizers/punkt/english.pickle")
extra_abbrev = {"b.c", "a.d", "b.c.e", "c.e", "e.g", "i.e", "etc", "dr", "mr", "mrs", "vs"}
sentence_tokenizer._params.abbrev_types.update(extra_abbrev)


def custom_sent_tokenize(text):
    return sentence_tokenizer.tokenize(text)


# -----------------------------
# Keyword extraction
# -----------------------------

def extract_keywords(sentence, amount=8):
    words = word_tokenize(sentence.lower())
    clean = [w for w in words if w.isalpha() and w not in STOP_WORDS]

    frequency = Counter(clean)
    return [word for word, count in frequency.most_common(amount)]


# -----------------------------
# Date/time detection
# -----------------------------

def find_dates(sentence):
    patterns = [
        # Years with optional eras (e.g., 27 BC, 27 B.C., 100 A.D.)
        r"\b\d{1,4}\s?(?:B\.?C\.?E?|A\.?D\.?|C\.?E\.?)\b",
        # Year ranges (e.g., 1914-1918)
        r"\b\d{4}\s?[-–]\s?\d{4}\b",
        # Decades (e.g., 1990s)
        r"\b\d{3}0s\b",
        # ISO dates (e.g., 2026-08-03)
        r"\b\d{4}-\d{2}-\d{2}\b",
        # Numeric dates (e.g., 12/31/2023 or 12-31-2023)
        r"\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b",
        # Full month dates (e.g., August 3rd, 2026 or August 3, 2026)
        r"\b(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2}(?:st|nd|rd|th)?,?\s+\d{4}\b",
        # Day Month Year (e.g., 3rd August 2026)
        r"\b\d{1,2}(?:st|nd|rd|th)?\s+(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{4}\b",
        # Month + year (e.g., August 2026)
        r"\b(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{4}\b",
        # Times with AM/PM
        r"\b\d{1,2}(?::\d{2})?\s?(?:AM|PM|am|pm)\b",
        # Times 24hr / HH:MM:SS
        r"\b\d{1,2}:\d{2}(?::\d{2})?\b",
        # Seasons + Year
        r"\b(?:Spring|Summer|Autumn|Fall|Winter)\s+\d{4}\b",
        # Standalone 4-digit years (placed last to prevent greedy short-circuits)
        r"\b\d{4}\b",
    ]

    found = []

    for pattern in patterns:
        matches = re.findall(pattern, sentence, flags=re.IGNORECASE)
        for match in matches:
            found.append(match.strip())

    relative_dates = [
        "today",
        "yesterday",
        "tomorrow",
        "last year",
        "next year",
        "this year",
        "recently",
        "century",
        "decade",
    ]

    lower_sentence = sentence.lower()

    for date in relative_dates:
        if date in lower_sentence:
            found.append(date)

    historical_periods = [
        "stone age",
        "bronze age",
        "iron age",
        "middle ages",
        "renaissance",
        "industrial revolution",
        "modern era",
        "ancient times",
    ]

    for period in historical_periods:
        if period in lower_sentence:
            found.append(period)

    found = list(dict.fromkeys(found))

    return found if found else None


# -----------------------------
# Topic detection
# -----------------------------

def detect_topic(sentence):
    text = sentence.lower()
    scores = {}

    for topic, words in TOPICS.items():
        score = 0
        for word in words:
            if word.lower() in text:
                score += 1
        scores[topic] = score

    best = max(scores, key=scores.get)

    if scores[best] == 0:
        return None

    return best


# -----------------------------
# Main converter
# -----------------------------

def convert_file(input_file, output_file):
    with open(input_file, "r", encoding="utf-8") as f:
        text = f.read()

    sentences = custom_sent_tokenize(text)

    data = {
        "source": os.path.basename(input_file),
        "sentence_count": len(sentences),
        "sentences": [],
    }

    for index, sentence in enumerate(sentences):
        item = {
            "id": index,
            "text": sentence,
            "keywords": extract_keywords(sentence),
            "dates_times": find_dates(sentence),
            "topic_genre": detect_topic(sentence),
        }
        data["sentences"].append(item)

    with open(output_file, "w", encoding="utf-8") as f:
        formatted = json.dumps(data, indent=4, ensure_ascii=False)
        f.write(formatted)

    print(f"Created {len(sentences)} semantic sentences")


# -----------------------------
# SETTINGS
# -----------------------------

convert_file("history-dataset.txt", "data.json")