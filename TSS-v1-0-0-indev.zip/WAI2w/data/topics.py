TOPICS = {

    "technology": [
        "computer","software","hardware","AI","artificial intelligence",
        "internet","network","server","database","code","coding","program",
        "algorithm","robot","machine learning","cybersecurity","encryption",
        "chip","processor","GPU","CPU"
    ],
    "gaming": [
      "game", "minecraft", "easports", "fortnite", "callofduty",
      "gaming", "gamer", "battle", "1v1", "4v4"  
    ],
    "creator": [
        "youtuber", "twitch", "streamer", "videos",
        "livestream", "monotization", "demonotization"
    ],
    "science": [
        "physics","biology","chemistry","chemical",
        "experiment","research","laboratory","scientist",
        "theory","molecule","atom","energy","quantum",
        "genetics","cell","organism","evolution","space"
    ],
    "astronomy": [
        "planet", "star", "galaxy", "universe",
        "moon","sun","black hole","cosmos",
        "telescope","NASA","orbit","asteroid"
    ],
    "history": [
        "war", "king", "queen", "empire", "ancient",
        "battle", "century", "civilization", "dynasty",
        "revolution", "colonial", "historical", "archaeology",
        "Roman", "Greek", "medieval", "ww1", "ww2", "ww3",
        "ukraine-russia"
    ],
    "greek": [
        "Zeus","Hera","Poseidon","Athena",
        "Apollo","Artemis","Ares","Hermes",
        "Aphrodite","Hephaestus","Demeter",
        "Dionysus","Hades"
    ],
    "norse": [
        "Odin","Thor","Loki",
        "Freyja","Tyr","Heimdall",
        "Baldr","Frigg","Njord","Hel"
    ],
    "egyptian": [
        "Ra", "Osiris","Isis","Anubis",
        "Horus","Set","Thoth","Bastet",
        "Hathor","Sekhmet"
    ],
    "hindu": [
        "Brahma","Vishnu","Shiva",
        "Krishna","Ganesha","Lakshmi",
        "Saraswati","Kali","Hanuman"
    ],
    "japanese_shinto": [
        "Amaterasu","Susanoo","Tsukuyomi",
        "Inari","Hachiman"
    ],
    "aztec": [
        "Quetzalcoatl","Tezcatlipoca","Huitzilopochtli",
        "Tlaloc","Xipe Totec"
    ],
    "mesopotamian": [
        "Marduk","Ishtar","Enki", 
        "Enlil", "Anu", "Ereshkigal"
    ],
    "celtic": [
        "Lugh", "Brigid","Dagda",
        "Cernunnos","Morrigan"
    ],
    "roman": [
        "Jupiter", "Juno", "Neptune",
        "Mars", "Venus", "Mercury",
        "Minerva", "Diana", "Vulcan","Pluto"
    ],
    "business": [
        "company","market","money","sales","industry","corporation",
        "startup","investment","profit","revenue","economy",
        "stock","finance","customer"
    ],
    "politics": [
        "government","president","election","law",
        "minister","parliament","democracy","republic",
        "constitution","policy","vote","campaign"
    ],
    "medicine": [
        "health","doctor","hospital","disease","virus",
        "medicine","treatment","patient","symptom",
        "diagnosis","surgery","vaccine","therapy"
    ],
    "engineering": [
        "engine","design","mechanical","electrical","construction",
        "machine","material","robotics","manufacturing",
        "prototype","system"
    ],
    "art": [
        "painting","artist","drawing","sculpture",
        "gallery","creative","design","visual",
        "portrait","photography"
    ],
    "music": [
        "song","music","album","artist",
        "band","instrument","piano","guitar",
        "composer","melody","rhythm","concert"
    ],
    "literature": [
        "book","novel","author","story",
        "poem","writing","character","fiction",
        "chapter","essay"
    ],
    "geography": [
        "country","city","river","mountain",
        "continent","ocean","map","location",
        "region","population", "ocean", "oceans",
        "land", "sea", "oasis"
    ],
    "sports": [
        "game", "team", "player", "football", "soccer",
        "basketball", "baseball", "hockey", "championship",
        "league", "score"
    ],
    "religion": [
        "religion", "church", "god", "belief", "faith", 
        "holy", "bible", "temple", "spiritual"
    ],
    "countries": [
        "Afghanistan",
        "Albania",
        "Algeria",
        "Andorra",
        "Angola",
        "Antigua and Barbuda",
        "Argentina",
        "Armenia",
        "Australia",
        "Austria",
        "Azerbaijan",

        "Bahamas",
        "Bahrain",
        "Bangladesh",
        "Barbados",
        "Belarus",
        "Belgium",
        "Belize",
        "Benin",
        "Bhutan",
        "Bolivia",
        "Bosnia and Herzegovina",
        "Botswana",
        "Brazil",
        "Brunei",
        "Bulgaria",
        "Burkina Faso",
        "Burundi",

        "Cabo Verde",
        "Cambodia",
        "Cameroon",
        "Canada",
        "Central African Republic",
        "Chad",
        "Chile",
        "China",
        "Colombia",
        "Comoros",
        "Costa Rica",
        "Croatia",
        "Cuba",
        "Cyprus",
        "Czechia",

        "Democratic Republic of the Congo",
        "Denmark",
        "Djibouti",
        "Dominica",
        "Dominican Republic",

        "Ecuador",
        "Egypt",
        "El Salvador",
        "Equatorial Guinea",
        "Eritrea",
        "Estonia",
        "Eswatini",
        "Ethiopia",

        "Fiji",
        "Finland",
        "France",

        "Gabon",
        "Gambia",
        "Georgia",
        "Germany",
        "Ghana",
        "Greece",
        "Grenada",
        "Guatemala",
        "Guinea",
        "Guinea-Bissau",
        "Guyana",

        "Haiti",
        "Honduras",
        "Hungary",

        "Iceland",
        "India",
        "Indonesia",
        "Iran",
        "Iraq",
        "Ireland",
        "Israel",
        "Italy",

        "Jamaica",
        "Japan",
        "Jordan",

        "Kazakhstan",
        "Kenya",
        "Kiribati",
        "Kuwait",
        "Kyrgyzstan",

        "Laos",
        "Latvia",
        "Lebanon",
        "Lesotho",
        "Liberia",
        "Libya",
        "Liechtenstein",
        "Lithuania",
        "Luxembourg",

        "Madagascar",
        "Malawi",
        "Malaysia",
        "Maldives",
        "Mali",
        "Malta",
        "Marshall Islands",
        "Mauritania",
        "Mauritius",
        "Mexico",
        "Micronesia",
        "Moldova",
        "Monaco",
        "Mongolia",
        "Montenegro",
        "Morocco",
        "Mozambique",
        "Myanmar",

        "Namibia",
        "Nauru",
        "Nepal",
        "Netherlands",
        "New Zealand",
        "Nicaragua",
        "Niger",
        "Nigeria",
        "North Korea",
        "North Macedonia",
        "Norway",

        "Oman",

        "Pakistan",
        "Palau",
        "Panama",
        "Papua New Guinea",
        "Paraguay",
        "Peru",
        "Philippines",
        "Poland",
        "Portugal",

        "Qatar",

        "Republic of the Congo",
        "Romania",
        "Russia",
        "Rwanda",

        "Saint Kitts and Nevis",
        "Saint Lucia",
        "Saint Vincent and the Grenadines",
        "Samoa",
        "San Marino",
        "Sao Tome and Principe",
        "Saudi Arabia",
        "Senegal",
        "Serbia",
        "Seychelles",
        "Sierra Leone",
        "Singapore",
        "Slovakia",
        "Slovenia",
        "Solomon Islands",
        "Somalia",
        "South Africa",
        "South Korea",
        "South Sudan",
        "Spain",
        "Sri Lanka",
        "Sudan",
        "Suriname",
        "Sweden",
        "Switzerland",
        "Syria",

        "Taiwan",
        "Tajikistan",
        "Tanzania",
        "Thailand",
        "Timor-Leste",
        "Togo",
        "Tonga",
        "Trinidad and Tobago",
        "Tunisia",
        "Turkey",
        "Turkmenistan",
        "Tuvalu",

        "Uganda",
        "Ukraine",
        "United Arab Emirates",
        "United Kingdom",
        "United States",
        "Uruguay",
        "Uzbekistan",

        "Vanuatu",
        "Vatican City",
        "Venezuela",
        "Vietnam",

        "Yemen",

        "Zambia",
        "Zimbabwe"
    ],

}